/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package factorial;
public class Factorial {
    public static void main(String[] args) {
        int numero=9, contador=1;
        long factorial=numero;
        while(contador < numero){
           factorial= factorial*contador;
           contador= contador +1;
        }
        System.out.println("El factorial del numero 5 es: "+ factorial);
        System.out.println(contador);
        System.out.println(numero);
        }
    
}
