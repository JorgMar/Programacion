/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package triangulo;

/**
 *
 * @author Alumno
 */
public class Triangulo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int lado1=7, lado2=5, lado3=7;
       if (lado1==lado2){
           if(lado2==lado3){
               System.out.println("El triangulo es equilatero");
           }
           else{
               System.out.println("El triangulo es isósceles");
           }           
       }
       else{
           if(lado1==lado3){
               System.out.println("El triangulo es isósceles");
           }
           else{
               if(lado2==lado3){
                   System.out.println("El triangulo es isósceles");
               }
               else{
                   System.out.println("El triangulo es escaleno");
               }
           }
       }
    }
    
}
